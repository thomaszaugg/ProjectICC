#Programmation Orientée-objets(SV)

##JOURNAL du groupe 144 (Thomas Zaugg, Lisa Kienle) 

*************************************************
Week 1


- Setting up the working environment caused no problems (all installation issues were solved beforehand)
- Reading through the descriptions and the different files of information
- Started coding together during TP session, finished CircularBody Class and started working on different methods of Substance class
- Didn't finish during TP, so divided the work and discussed it on Friday
- Part 1 is running and passing all the tests since Friday evening


*************************************************
Week 2


- As preparation for TP2 we already read the instructions given for part 2
- Started working at 8 o'clock
- Divided the tasks (Lisa Animal House; Tom Hamster and Pellet Portion) and prepared questions to ask during TP
- Advanced well during TP
- Tried finishing on Friday, compilation problems when including the Hamsper.hpp in the Lab, waited for TP to resolve these


*************************************************
Week 3


- We set up GitHub to share our files more effectively
- We realized the problem of week 2 was due to ciruclar dependecies and we were able to solve it with the help of the TA
- We split up the work during TP: Lisa does 3.1 and Tom 3.2


*************************************************

Week 4


- We used the whole TP to debugg part 3.1 and 3.2, everything working at the end of it
- Didn't do a lot of coding during this week
- Commented our code and restructured it to have it clean for the rendu intermediare
- Coded part 3.3 over the weekend

*************************************************

Week 5


- Debugged part 3.3 on Monday (Hamster was walking in Circles to target food...)
- Didn't advance well during TP (only beginning of 4.1)
- Discovered a problem with part 3 (if two hamsters are in a Lab and one dies, the programm crashes)
- Solved the problem and uploaded a first version for the rendu intermediare


