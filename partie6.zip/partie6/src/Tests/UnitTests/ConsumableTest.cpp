/*
* prjsv 2018
* 2016
* Marco Antognini
* fev 2018
* Antoine Madrona
*/

#include <Application.hpp>
#include <Env/Hamster.hpp>
#include <Env/Pellets.hpp>
#include <Config.hpp>
#include <catch.hpp>
#include <iostream>


SCENARIO("Hamster vs Entity", "[Hamster]")
{
    Entity* mickey(new Hamster({0,0}));
    Entity* winnie(new Hamster({0,0}));
    Entity* nuts(new Pellets({0,0}));

    GIVEN("A Hamster") {
        THEN("No autophagy") {
            CHECK_FALSE(mickey->canConsume(mickey));
        }
    }

    GIVEN("Two hamsters") {
        THEN("No cannibalism") {
            CHECK_FALSE(mickey->canConsume(winnie));
            CHECK_FALSE(winnie->canConsume(mickey));
        }
    }

    GIVEN("A Hamster and a portion of Pellets") {
        THEN("the Pellets are eatable by the Hamster") {
            CHECK(mickey->canConsume(nuts));
        }
        THEN("the Hamster is not eatable by the Pellets") {
            CHECK_FALSE(nuts->canConsume(mickey));
        }
    }

    delete mickey;
    delete winnie;
    delete nuts;
}

SCENARIO("Pellets vs Entity", "[Pellets]")
{

    Entity* mickey(new Hamster({0,0}));
    Entity* fruits(new Pellets({0,0}));
    Entity* nuts(new Pellets({0,0}));

    GIVEN("A portion of pellets") {
        THEN("No autophagy") {
            CHECK_FALSE(fruits->canConsume(fruits));
        }
    }

    GIVEN("Two portions of Pellets") {
        THEN("No cannibalism") {
            CHECK_FALSE(nuts->canConsume(fruits));
            CHECK_FALSE(fruits->canConsume(nuts));
        }
    }

    GIVEN("A Pellets and a Hamster") {
        THEN("The Pellets is eatable by the Hamster") {
            CHECK(mickey->canConsume(fruits));
        }
        THEN("the Hamster is not eatable by the Pellets") {
            CHECK_FALSE(fruits->canConsume(mickey));
        }
    }

    delete mickey;
    delete fruits;
    delete nuts;
}
