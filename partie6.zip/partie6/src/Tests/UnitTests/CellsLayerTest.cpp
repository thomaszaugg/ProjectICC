/*
 * POOSV 2024
 *
 */

#include <Application.hpp>
#include <Env/Organ.hpp>
#include <Env/CellsLayer.hpp>
#include <Tests/UnitTests/CheckUtility.hpp>
#include <Utility/Constants.hpp>

#include <catch.hpp>
#include <iostream>

class EmptyOrgan : public Organ
{
public:
	EmptyOrgan()
		:Organ(false)
		{
			generate();
		}
     // shadowing here
	// overriding is useless since polymorphic behaviour is ignored
	// in constructors
	void generate() 
	{
		reloadConfig();
	}

	// prevents updating representation in empty organ
	void updateRepresentationAt(const CellCoord&) override
		{}

	int getGridSize()
		{
			return getAppConfig().simulation_organ_nbCells;
		}
	
};

SCENARIO("Constructing CellsLayer", "[CellsLayer]")
{
    WHEN("Explicit Constructor is used")
    {
    	
		EmptyOrgan* emptyOrgan(new EmptyOrgan());
		CellCoord pos(emptyOrgan->getGridSize()/2,emptyOrgan->getGridSize()/2);
        CellsLayer ch(pos, emptyOrgan);

        THEN("CellsLayer has ECM cell but no Organ and no Blood cell")
        {
            CHECK_FALSE(ch.hasOrganCell());
            CHECK_FALSE(ch.hasBloodCell());
            CHECK(ch.hasECMCell());
        }
		delete emptyOrgan;
    }
}

SCENARIO("Manipulating/Constructing a CellsLayer", "[CellsLayer]")
{
    GIVEN("An organ with 4 CellsLayers")
	{
		EmptyOrgan* organ(new EmptyOrgan());
		auto x(organ->getGridSize()/2);
		auto y(organ->getGridSize()/2);
		CellCoord pos1(x,y);
        CellCoord pos2(x+1,y);
        CellCoord pos3(x,y+1);
        CellCoord pos4(x+1,y+1);

        CellsLayer CellsLayer1(pos1, organ);
        CellsLayer CellsLayer2(pos2, organ);
        CellsLayer CellsLayer3(pos3, organ);
        CellsLayer CellsLayer4(pos4, organ);

        WHEN("Adding Blood (type capillary) to CellsLayer1")
        {
            CellsLayer1.setBlood(TypeBloodCell::CAPILLARY);
            THEN("The Capillary is well added")
            {
                CHECK(CellsLayer1.hasBloodCell());
                CHECK_FALSE(CellsLayer1.hasOrganCell());
            }
        }

        WHEN("Adding OrganCell to CellsLayer1")
        {
            CellsLayer1.setOrganCell();
            THEN("The OrganCell is well added")
            {
                CHECK_FALSE(CellsLayer1.hasBloodCell());
                CHECK(CellsLayer1.hasOrganCell());
            }
        }
		delete organ;
    }
}

SCENARIO("updateSubstance and organCellTakeFromECM methods, [CellsLayer]")
{
    GIVEN("An organ with 4 CellsLayers")
    {
		EmptyOrgan* organ(new EmptyOrgan());
		auto x(organ->getGridSize()/2);
		auto y(organ->getGridSize()/2);
		CellCoord pos1(x,y);

        CellsLayer CellsLayer1(pos1, organ);

        WHEN("OrganCell takes 50% GLUCOSE from its ECM and ECM has (200.0, 300.0, 400.) as Substance (1 step)")
        {
			Substance substance(200., 300., 400.);
            CellsLayer1.setOrganCell();
            CellsLayer1.updateSubstance(substance);

            THEN("before taking, OrganCell has zero GLUCOSE")
            {
                 CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 300.);
                 CHECK(CellsLayer1.getECMQuantity(VGEF) == 200.);
                 CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 400.);
                 CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
			}

            CellsLayer1.organCellTakeFromECM(GLUCOSE, 0.5);

            THEN("after taking, ECMCell and OrganCell are well updated")
            {
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(GLUCOSE),150.);
                CHECK(CellsLayer1.getECMQuantity(VGEF) == 200.);
                CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 400.);
                CHECK_APPROX_EQUAL(CellsLayer1.getOrganCellQuantity(GLUCOSE), 150.);
                CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
            }
		}

        WHEN("OrganCell takes 5% GLUCOSE from its ECM and ECM has (200.0, 300.0, 400.) as Substance (10 steps)")
        {
            Substance substance(200., 300., 400.);
            CellsLayer1.setOrganCell();
            CellsLayer1.updateSubstance(substance);
            THEN("before taking, OrganCell has zero GLUCOSE")
            {
                 CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 300.);
                 CHECK(CellsLayer1.getECMQuantity(VGEF) == 200.);
                 CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 400.);
                 CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
            }

            for (unsigned int i(0); i<10; ++i)
            {
                CellsLayer1.organCellTakeFromECM(GLUCOSE, 0.05);
            }

            THEN("after taking (10 steps), ECM and OrganCell are well updated")
            {
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(GLUCOSE), 179.621);
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(VGEF), 200.);
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(BROMOPYRUVATE), 400.);
                CHECK_APPROX_EQUAL(CellsLayer1.getOrganCellQuantity(GLUCOSE), 120.379);
                CHECK_APPROX_EQUAL((CellsLayer1.getECMQuantity(GLUCOSE)+
                    CellsLayer1.getOrganCellQuantity(GLUCOSE)), 300);
                CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
            }
        }

        WHEN("OrganCell takes 50% GLUCOSE from its ECM and ECM has (0., 0., 0.) as Substance (1 step)")
        {
            Substance substance(0., 0., 0.);
            CellsLayer1.setOrganCell();
            CellsLayer1.updateSubstance(substance);
            THEN("before taking, OrganCell has zero GLUCOSE")
            {
                 CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getECMQuantity(VGEF) == 0.);
                 CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
            }
            CellsLayer1.organCellTakeFromECM(GLUCOSE, 0.5);
            THEN("after taking, ECMCell and OrganCell are well updated")
            {
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(GLUCOSE), 0.);
                CHECK(CellsLayer1.getECMQuantity(VGEF) == 0.);
                CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 0.);
                CHECK_APPROX_EQUAL(CellsLayer1.getOrganCellQuantity(GLUCOSE), 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
            }
        }

        WHEN("OrganCell takes 0% VGEF from its ECM and ECM has (200., 400., 300.) as Substance (1 step)")
        {
            Substance substance(400., 400., 300.);
            CellsLayer1.setOrganCell();
            CellsLayer1.updateSubstance(substance);
            THEN("before taking, OrganCell has zero VGEF")
            {
                 CHECK(CellsLayer1.getECMQuantity(VGEF) == 400.);
                 CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 400.);
                 CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 300.);
                 CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
            }
            CellsLayer1.organCellTakeFromECM(VGEF, 0.);
            THEN("after taking, ECMCell and OrganCell are well updated")
            {
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(VGEF), 400.);
                CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 400.);
                CHECK(CellsLayer1.getECMQuantity(BROMOPYRUVATE) == 300.);
                CHECK_APPROX_EQUAL(CellsLayer1.getOrganCellQuantity(GLUCOSE), 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
            }
        }

        WHEN("OrganCell takes 60% BROMOPYRUVATE from its ECM and ECM has (200., 400., 2*SUBSTANCE_PRECISION) as Substance (1 step)")
        {
            Substance substance(400., 400., 2*SUBSTANCE_PRECISION);
            CellsLayer1.setOrganCell();
            CellsLayer1.updateSubstance(substance);
            THEN("before taking, OrganCell has zero BROMOPYRUVATE")
            {
                 CHECK(CellsLayer1.getECMQuantity(VGEF) == 400.);
                 CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 400.);
                 CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(BROMOPYRUVATE), 2*SUBSTANCE_PRECISION);
                 CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
            }
            CellsLayer1.organCellTakeFromECM(BROMOPYRUVATE, 0.6);
            THEN("after taking, ECMCell and OrganCell are well updated (taking care of SUBSTANCE_PRECISION aspect)")
            {
                CHECK(CellsLayer1.getECMQuantity(VGEF) == 400.);
                CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 400.);
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(BROMOPYRUVATE), 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                CHECK_APPROX_EQUAL(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE), 1.2*SUBSTANCE_PRECISION);
            }
        }

        WHEN("OrganCell takes 1% BROMOPYRUVATE from its ECM and ECM has (200., 400., 2*SUBSTANCE_PRECISION) as Substance (1 step)")
        {
            Substance substance(400., 400., 2*SUBSTANCE_PRECISION);
            CellsLayer1.setOrganCell();
            CellsLayer1.updateSubstance(substance);
            THEN("before taking, OrganCell has zero BROMOPYRUVATE")
            {
                 CHECK(CellsLayer1.getECMQuantity(VGEF) == 400.);
                 CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 400.);
                 CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(BROMOPYRUVATE), 2*SUBSTANCE_PRECISION);
                 CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                 CHECK(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE) == 0.);
            }
            CellsLayer1.organCellTakeFromECM(BROMOPYRUVATE, 0.01);
            THEN("after taking, ECMCell and OrganCell^ are well updated (taking care of SUBSTANCE_PRECISION aspect)")
            {
                CHECK(CellsLayer1.getECMQuantity(VGEF) == 400.);
                CHECK(CellsLayer1.getECMQuantity(GLUCOSE) == 400.);
                CHECK_APPROX_EQUAL(CellsLayer1.getECMQuantity(BROMOPYRUVATE), 1.98*SUBSTANCE_PRECISION);
                CHECK(CellsLayer1.getOrganCellQuantity(VGEF) == 0.);
                CHECK(CellsLayer1.getOrganCellQuantity(GLUCOSE) == 0.);
                CHECK_APPROX_EQUAL(CellsLayer1.getOrganCellQuantity(BROMOPYRUVATE), 0.);
            }
        }
		delete organ;
	}
}

SCENARIO("isOut() method", "[CellsLayer]")
{
    GIVEN("One CellsLayer and several coordinates")
    {
		EmptyOrgan* emptyOrgan(new EmptyOrgan());
		auto width = emptyOrgan->getGridSize();
		auto height = emptyOrgan->getGridSize();
	

        CellCoord cc1(width/2,height/2);

        CellsLayer CH(cc1, emptyOrgan);
		
        CellCoord cc2(width,height-1);
        CellCoord cc3(width-1,height);
        CellCoord cc4(width,height);
        CellCoord cc5(0,0);
        CellCoord cc6(-5,0);
        CellCoord cc7(-2,-4);

        WHEN("Testing coordinates exceeding the width or height of the organ to which belongs the CellsLayer")
        {
            THEN("they are outside")
            {
                CHECK(CH.isOut(cc2));
				CHECK(CH.isOut(cc3));
				CHECK(CH.isOut(cc4));
            }
        }
        WHEN("Testing (width/2,height/2) coordinate")
        {
            THEN("it is inside")
            {
                CHECK_FALSE(CH.isOut(cc1));
            }
        }

		 WHEN("Testing (0,0) coordinate")
        {
            THEN("it is inside")
            {
                CHECK_FALSE(CH.isOut(cc5));
            }
        }
        WHEN("Testing negative coordinates")
        {
            THEN("they are outside")
            {
                CHECK(CH.isOut(cc6));
				CHECK(CH.isOut(cc7));
            }
        }

		delete emptyOrgan;
    }
}
