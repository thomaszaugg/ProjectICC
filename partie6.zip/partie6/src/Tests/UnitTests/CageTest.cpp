/*
 * POOSV 2024
 */

#include <Tests/UnitTests/CheckUtility.hpp>
#include <Application.hpp>
#include <Env/Cage.hpp>
#include <catch.hpp>
#include <iostream>


SCENARIO("Constructing Cage", "[Cage]")
{
    WHEN("Explicit constructor is used with default values") {
        Cage cage1 ({400, 400});

        THEN("Attributes are well initialised") {
            CHECK(cage1.getCenter().x() == 400);
            CHECK(cage1.getCenter().y() == 400);
            CHECK(cage1.getHeight() == 300);
            CHECK(cage1.getWidth() == 300);
            CHECK(cage1.getWallWidth() == 10);
        }
    }
}


SCENARIO("Testing isPositionInside method", "[Cage]")
{
    GIVEN("A Cage centered in (400,400)") {
        Cage cage({400,400});

        WHEN("Testing position (400, 400)") {
            THEN("(400, 400) is inside") {
                CHECK(cage.isPositionInside({400,400}) == true);
            }
        }

        WHEN("Testing position (530, 400)") {
            THEN("(530, 400) is inside") {
                CHECK(cage.isPositionInside({530,400}) == true);
            }
        }

        WHEN("Testing position (270, 400)") {
            THEN("(270, 400) is inside") {
                CHECK(cage.isPositionInside({270,400}) == true);
            }
        }

        WHEN("Testing position (400, 530)") {
            THEN("(400, 530) is inside") {
                CHECK(cage.isPositionInside({400,530}) == true);
            }
        }

        WHEN("Testing position (400, 270)") {
            THEN("(400, 270) is inside") {
                CHECK(cage.isPositionInside({400,270}) == true);
            }
        }

        WHEN("Testing position (540, 540)") {
            THEN("(540, 540) is not inside") {
                CHECK_FALSE(cage.isPositionInside({540,540}));
            }
        }

        WHEN("Testing position (260, 260)") {
            THEN("(260, 260) is not inside") {
                CHECK_FALSE(cage.isPositionInside({260,260}));
            }
        }


        WHEN("Testing position (270, 270)") {
            THEN("(260, 260) is not inside") {
                CHECK(cage.isPositionInside({270,270}));
            }
        }

        WHEN("Testing position (538, 468)") {
            THEN("(538, 468) is inside") {
                CHECK(cage.isPositionInside({538,468}));
            }
        }

        WHEN("Testing position (0, 0)") {
            THEN("(0, 0) is not inside") {
                CHECK_FALSE(cage.isPositionInside({0,0}));
            }
        }

        WHEN("Testing position (400, 700)") {
            THEN("(400, 700) is not inside") {
                CHECK_FALSE(cage.isPositionInside({400,700}));
            }
        }

        WHEN("Testing position (700, 400)") {
            THEN("(700, 400) is not inside") {
                CHECK_FALSE(cage.isPositionInside({700,400}));
            }
        }

        WHEN("Testing position (600, 600)") {
            THEN("(600, 600) is outside") {
                CHECK(cage.isPositionInside({600,600}) == false);
            }
        }

        WHEN("Testing position (249, 400)") {
            THEN("(249, 400) is not inside") {
                CHECK_FALSE(cage.isPositionInside({249,400}));
            }
        }

        WHEN("Testing position (249, 249)") {
            THEN("(249, 249) is not inside") {
                CHECK_FALSE(cage.isPositionInside({249,249}));
            }
        }
    }
}

SCENARIO("Testing isPositionOnWall method (using isPositionInside too)", "[Cage]")
{
    GIVEN("A Cage centered in (400,400)") {
        Cage cage({400,400});

        WHEN("Testing position (400, 400)") {
            THEN("(400, 400) is inside and not on a wall") {
                CHECK((cage.isPositionInside({400,400}) && ! cage.isPositionOnWall({400,400})));
                CHECK_FALSE(cage.isPositionOnWall({400,400}));
            }
        }

        WHEN("Testing position (549, 400)") {
            THEN("(549, 400) is on a wall") {
                CHECK((!cage.isPositionInside({549,400}) && cage.isPositionOnWall({549,400})));
                CHECK(cage.isPositionOnWall({549,400}));
            }
        }

        WHEN("Testing position (540, 400)") {
            THEN("(540, 400) is on a wall") {
                CHECK((!cage.isPositionInside({540,400}) && cage.isPositionOnWall({540,400})));
                CHECK(cage.isPositionOnWall({540,400}));
            }
        }

        WHEN("Testing position (251, 400)") {
            THEN("(251, 400) is on a wall") {
                CHECK((!cage.isPositionInside({251,400}) && cage.isPositionOnWall({251,400})));
                CHECK(cage.isPositionOnWall({251,400}));
            }
        }

        WHEN("Testing position (260, 400)") {
            THEN("(260, 400) is on a wall") {
                CHECK((!cage.isPositionInside({260,400}) && cage.isPositionOnWall({260,400})));
                CHECK(cage.isPositionOnWall({260,400}));
            }
        }

        WHEN("Testing position (400, 251)") {
            THEN("(400, 251) is on a wall") {
                CHECK((!cage.isPositionInside({400,251}) && cage.isPositionOnWall({400,251})));
                CHECK(cage.isPositionOnWall({400,251}));
            }
        }

        WHEN("Testing position (400, 260)") {
            THEN("(400, 260) is on a wall") {
                CHECK((!cage.isPositionInside({400,260}) && cage.isPositionOnWall({400,260})));
                CHECK(cage.isPositionOnWall({400,260}));
            }
        }

        WHEN("Testing position (600, 600)") {
            THEN("(600, 600) is not inside and not on a wall") {
                CHECK((!cage.isPositionInside({600,600}) && !cage.isPositionOnWall({600,600}) ));
            }
        }

        WHEN("Testing position (539, 539)") {
            THEN("(539, 539) is not on a wall") {
                CHECK_FALSE(cage.isPositionOnWall({539,539}));
            }
        }

        WHEN("Testing position (400, 539)") {
            THEN("(400, 539) is not on a wall") {
                CHECK(( cage.isPositionInside({400,539}) && !cage.isPositionOnWall({400,539}) ));
            }
        }

        WHEN("Testing position (412, 398)") {
            THEN("(412, 398) is not on a wall") {
                CHECK((cage.isPositionInside({412,398}) && !cage.isPositionOnWall({412,398}) ));
            }
        }

        WHEN("Testing position (412, 545)") {
            THEN("(412, 545) is on a wall") {
                CHECK(( !cage.isPositionInside({412,545}) && cage.isPositionOnWall({412,545}) ));
            }
        }

        WHEN("Testing position (243.7, 600)") {
            THEN("(243.7, 600) is not on a wall") {
                CHECK_FALSE(cage.isPositionOnWall({243.7,600}));
            }
        }
    }
}

SCENARIO("Walls & Limits getters", "[Cage]")
{
    GIVEN("A Cage centered in (400, 300)") {
        Cage cage({400,300});

        WHEN("Getting the top and bottom limits") {
            THEN("The right values are returned") {
                CHECK(cage.getTopLimit() < cage.getBottomLimit());
                CHECK(cage.getTopLimit() == 150);
                CHECK(cage.getBottomLimit() == 450);
            }
        }

        WHEN("Getting the left and right limits") {
            THEN("The right values are returned") {
                CHECK(cage.getLeftLimit() < cage.getRightLimit());
                CHECK(cage.getLeftLimit() == 250);
                CHECK(cage.getRightLimit() == 550);
            }
        }

        WHEN("Getting the limits with offset") {
            THEN("The right values are returned (half of wallwidth took in account)") {
                CHECK(cage.getTopLimit(true) == 160);
                CHECK(cage.getBottomLimit(true) == 440);
                CHECK(cage.getLeftLimit(true) == 260);
                CHECK(cage.getRightLimit(true) == 540);
            }
        }
    }
}
