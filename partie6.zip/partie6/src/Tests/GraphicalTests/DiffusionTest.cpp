/*
 * POOSV 2024
 * Marco Antognini & Jamila Sam
 */

#include <Tests/GraphicalTests/DiffusionTest.hpp>
#include <Utility/Utility.hpp>
#include <Env/Organ.hpp>
#include <Env/Lab.hpp>
#include <Env/Hamster.hpp>

IMPLEMENT_MAIN(DiffusionTest)

void DiffusionTest::onRun()
{
}
void DiffusionTest::onSimulationStart()
{
	mCurrentOrgan = new TransplantOrgan();
    mTransplantedHamster = new TransplantedHamster(getApp().getLabSize()/2);
    mTransplantedHamster->replaceOrgan(mCurrentOrgan);
	mSimulationStart = true;
}

void DiffusionTest::onUpdate(sf::Time /*dt*/)
{
	if (mSimulationStart){
		getAppEnv().reset();
        getAppEnv().addAnimal(mTransplantedHamster);
        getAppEnv().trackAnimal(mTransplantedHamster);
		getApp().switchToView(ECM);
		mSimulationStart = false;
	}
}

void DiffusionTest::onEvent(sf::Event event, sf::RenderWindow&)
{
if (event.type == sf::Event::KeyPressed) {
	switch (event.key.code) {
		case sf::Keyboard::A:
			{
				Vec2d physicalPos(getCursorPositionInView());
				CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
                mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Artery);
			}
				break;
		case sf::Keyboard::B:
			{
				Vec2d physicalPos(getCursorPositionInView());
				CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
                mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Capillary);
			}
				break;
	

			case sf::Keyboard::S: // S stands for Substance
			{
				if (isOrganViewOn()){
					toggleConcentrationView();
				}
			}
				break;	
		default:
			break;
			}
	}
}
/*
  void DiffusionTest::resetStats(){
  // Application::resetStats();

  }
*/
void DiffusionTest::onDraw(sf::RenderTarget& /*target*/)
{
  // ADD INSTRUCTIONS IF NEEDED
}
std::string DiffusionTest::getWindowTitle() const {
  return getAppConfig().window_title  + " (DiffusionTest)";
}

std::string DiffusionTest::getHelpTextFile() const {
    return RES_LOCATION + "help-diffusion.txt";
}
