/*
 * POOSV 2024
 * Marco Antognini & Jamila Sam
 */

#include <Tests/GraphicalTests/OrganTest.hpp>
#include <Utility/Utility.hpp>
#include <Env/Organ.hpp>
#include <Env/Lab.hpp>
#include <Env/Hamster.hpp>

IMPLEMENT_MAIN(OrganTest)

void OrganTest::onRun()
{
  // Setup stats
  Application::onRun();

}
void OrganTest::onSimulationStart()
{
  Application::onSimulationStart();
  mSimulationStart = true;
  mTransplantedHamster = new  TransplantedHamster(getApp().getLabSize()/2);
  mCurrentOrgan = new TransplantOrgan();
  mTransplantedHamster->replaceOrgan(mCurrentOrgan);
}

void OrganTest::onUpdate(sf::Time /*dt*/)
{
  if (mSimulationStart){
    getAppEnv().reset();
    getAppEnv().addAnimal(mTransplantedHamster);
    getAppEnv().trackAnimal(mTransplantedHamster);
    getApp().switchToView(ECM);
    mSimulationStart = false;
  }
}

void OrganTest::onEvent(sf::Event event, sf::RenderWindow&)
{
  if (event.type == sf::Event::KeyPressed) {
    switch (event.key.code) {
    case sf::Keyboard::B:
      {

	// UNCOMMENT WHEN READY
	Vec2d physicalPos(getCursorPositionInView());
	CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
	mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Capillary);
      }

      break;
    case sf::Keyboard::J:
      {

	// UNCOMMENT WHEN READY
	Vec2d physicalPos(getCursorPositionInView());
	CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
	mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Organ);			}

      break;


    case sf::Keyboard::X:
      {

	// UNCOMMENT IN STEP6
	Vec2d physicalPos(getCursorPositionInView());
	mCurrentOrgan->setCancerAt(physicalPos);
	}


      break;
				
    case sf::Keyboard::S: // S stands for Substance
      {
	if (isOrganViewOn()){
	  toggleConcentrationView();
	}
      }
      break;

		
    case sf::Keyboard::N: // next substance
      {

	// UNCOMMENT IN STEP6
	if (isOrganViewOn()){
	getAppEnv().nextSubstance();
	}

      }
      break;

    case sf::Keyboard::Num3: // increase substance
    case sf::Keyboard::PageUp:
      {

	// UNCOMMENT IN STEP6
	if (isOrganViewOn()){
	getAppEnv().increaseCurrentSubst();
	}

      }
      break;

    case sf::Keyboard::Num2: // decrease substance
    case sf::Keyboard::PageDown:
      {

	// UNCOMMENT IN STEP6
	if (isOrganViewOn()){		
	getAppEnv().decreaseCurrentSubst();
	}

      }
      break;
    default:
      break;
    }
  }
}



void OrganTest::onDraw(sf::RenderTarget& /*target*/)
{
  // ADD INSTRUCTIONS IF NEEDED
}
std::string OrganTest::getWindowTitle() const {
  return getAppConfig().window_title  + " (OrganTest)";
}
std::string OrganTest::getHelpTextFile() const {
  return RES_LOCATION + "help-organ.txt";
}
