/*
 *  POOSV 2024
 * Marco Antognini & Jamila Sam
 */

#include <Tests/GraphicalTests/LabTest.hpp>
#include <Env/Lab.hpp>
#include <Env/Hamster.hpp>
#include <Env/Pellets.hpp>
#include <Utility/Utility.hpp>

IMPLEMENT_MAIN(LabTest)

void LabTest::onRun()
{
    Application::onRun();
}

void LabTest::onEvent(sf::Event event, sf::RenderWindow&)
{
    if (event.type == sf::Event::KeyPressed) {
        switch (event.key.code) {
        case sf::Keyboard::H: {
            getAppEnv().addAnimal(new Hamster
                                  (getCursorPositionInView()));
        }
        break;

        case sf::Keyboard::F: { // F for food
            auto new_pellets = new Pellets (getCursorPositionInView());
            if (getAppEnv().addFood(new_pellets)) {
                mLastCreatedPellets = new_pellets;
            }

        }
        break;
        case sf::Keyboard::E: { //E for "Eat"
            if (mLastCreatedPellets != nullptr) {
                mLastCreatedPellets->provideEnergy(10);
                if (mLastCreatedPellets->getEnergy() < 10) { // CREATE THE getEnergy GETTER OR ADAPT ITS NAME
                    mLastCreatedPellets = nullptr;
                }
            }
        }
        break;

        default:
            break;
        }
    }
}
/*
  void LabTest::resetStats(){
  // Application::resetStats();

  }
*/
void LabTest::onDraw(sf::RenderTarget& /*target*/)
{
    // ADD INSTRUCTIONS IF NEEDED
}
std::string LabTest::getWindowTitle() const
{
    return getAppConfig().window_title  + " (LabTest)";
}

std::string LabTest::getHelpTextFile() const
{
    return RES_LOCATION + "help-lab.txt";
}
