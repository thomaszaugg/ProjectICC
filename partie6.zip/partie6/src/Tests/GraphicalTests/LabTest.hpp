/*
 *  POOSV 2024
 * Marco Antognini & Jamila Sam
 */


#pragma once

#include <Application.hpp>

/*!
 * Test confining and behaviour of hamsters in boxes
 *
 * Generate one target on click
 */

class LabTest : public Application
{
public:
    LabTest(int argc, char const** argv)
        : Application(argc, argv) { }
    virtual void onRun() override final;
    virtual void onEvent(sf::Event event, sf::RenderWindow& window) override final;
    virtual void onDraw(sf::RenderTarget& target) override final;
    //virtual void resetStats() override final;
    std::string virtual getWindowTitle() const override final;
    std::string getHelpTextFile() const override final;
private:
    Pellets* mLastCreatedPellets = nullptr;
};

