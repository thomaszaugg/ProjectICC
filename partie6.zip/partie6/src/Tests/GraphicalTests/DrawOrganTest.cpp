/*
 * POOSV 2024
 * Marco Antognini & Jamila Sam
 */

#include <Tests/GraphicalTests/DrawOrganTest.hpp>
#include <Utility/Utility.hpp>
#include <Env/Organ.hpp>
#include <Env/Lab.hpp>
#include <Env/Hamster.hpp>

IMPLEMENT_MAIN(DrawOrganTest)

void DrawOrganTest::onRun()
{
  Application::onRun();
}
void DrawOrganTest::onSimulationStart()
{
  Application::onSimulationStart();
  mCurrentOrgan = new TransplantOrgan();
  mGuineaPig = new GuineaPigMouse(getApp().getLabSize()/2);
  mGuineaPig->replaceOrgan(mCurrentOrgan);
  mSimulationStart = true;
}

void DrawOrganTest::onUpdate(sf::Time /*dt*/)
{
  if (mSimulationStart){
    getAppEnv().reset();
    getAppEnv().addAnimal(mGuineaPig);
    getAppEnv().trackAnimal(mGuineaPig);
    getApp().switchToView(ECM);
    mSimulationStart = false;
  }
}

void DrawOrganTest::onEvent(sf::Event event, sf::RenderWindow&)
{
  if (event.type == sf::Event::KeyPressed) {
    switch (event.key.code) {
    case sf::Keyboard::A:
      {

	// UNCOMMENT WHEN READY
	Vec2d physicalPos(getCursorPositionInView());
	CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
	mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Artery);
      }

      break;
    case sf::Keyboard::B:
      {

	// UNCOMMENT WHEN READY
	Vec2d physicalPos(getCursorPositionInView());
	CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
	mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Capillary);
      }

      break;		
    case sf::Keyboard::J:
      {

	// UNCOMMENT WHEN READY
	Vec2d physicalPos(getCursorPositionInView());
	CellCoord pos(mCurrentOrgan->toCellCoord(physicalPos));
	mCurrentOrgan->updateCellsLayer(pos, Organ::Kind::Organ);
      }

      break;
    case sf::Keyboard::N: // next substance
      {

	// UNCOMMENT in STEP6
	if (isOrganViewOn()){
	getAppEnv().nextSubstance();
	}

      }
      break;
    case sf::Keyboard::Num3: // increase substance
    case sf::Keyboard::PageUp: // increase substance
      {

	// UNCOMMENT IN STEP6
	if (isOrganViewOn()){
	getAppEnv().increaseCurrentSubst();
	}

      }
      break;
    case sf::Keyboard::Num2: // decrease substance
    case sf::Keyboard::PageDown: // decrease substance
      {

	// UNCOMMENT IN STEP 6
	if (isOrganViewOn()){
	getAppEnv().decreaseCurrentSubst();
	}

      }
      break;
    default:
      break;
    }
  }
}

void DrawOrganTest::onDraw(sf::RenderTarget& /*target*/)
{
  // ADD INSTRUCTIONS IF NEEDED
}
std::string DrawOrganTest::getWindowTitle() const {
  return getAppConfig().window_title  + " (DrawOrganTest)";
}
std::string DrawOrganTest::getHelpTextFile() const {
  return RES_LOCATION + "help-drawOrgan.txt";
}
