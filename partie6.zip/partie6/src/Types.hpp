/*
 *  POOSV 2024
 * Marco Antognini & Jamila Sam
 */

#pragma once
enum View {
    ORGAN=0,
    ECM,
    LAB,
    CONCENTRATION
};

enum SubstanceId {
    GLUCOSE=0,
    BROMOPYRUVATE,
    VGEF,
    NB_SUBST
};

enum TypeBloodCell {
    ARTERY=0,
    CAPILLARY,
    UNDEFINED
};


