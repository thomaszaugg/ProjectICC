/*
 * POOSV
 * 2016-2024
 * Marco Antognini
 */

#pragma once

#include <random>

/**
 *  @brief  Get a unique random number generator
 *
 *  @return always the same generator
 */
std::mt19937& getRandomGenerator();

