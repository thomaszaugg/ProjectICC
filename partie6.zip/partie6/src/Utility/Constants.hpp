/*
 *  POOSV 2024
 * Marco Antognini & Jamila Sam
*/

#pragma once
#include <string>

// Numerical constants
double const DEG_TO_RAD = 0.0174532925; ///< Degree to Radian conversion constant
double const TAU = 6.283185307;         ///< TAU constant (= 2 * PI)
double const PI = 3.141592654;          ///< PI constant
double const EPSILON = 1e-8;            ///< a small epsilon value
double const SUBSTANCE_PRECISION = 0.001;
//double const SUBSTANCE_PRECISION = +1E-9;

// Define resources location
std::string const RES_LOCATION = "../res/";

// Define the location of the config file
std::string const DEFAULT_CFG = "app.json";

// Define the location of the font file (could be in the config instead of here)
std::string const APP_FONT_LOCATION = RES_LOCATION + "sansation.ttf";

// Stats titles
namespace s
{

std::string const GENERAL = "general";
std::string const HAMSTER   = "hamster";
std::string const FOOD  = "food";
std::string const ANIMAL_INDIVIDUAL = "Tracked Animal";
std::string const FOOD_INDIVIDUAL   = "Tracked food";

std::string const INDIVIDUAL = "Tracked Animal";
std::string const ENERGY = "energy";
std::string const HEALTH = "health";
std::string const DELTAGLUC = "Delta Glucose";
std::string const DELTABROM = "Delta Bromopyruvate";
std::string const DELTAVGEF = "Delta VGEF";
std::string const CURRENTSUBST = "Current Substance";

} // s

