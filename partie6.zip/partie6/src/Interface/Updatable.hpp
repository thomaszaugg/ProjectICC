
/*
 * POOSV 2016-2024
 * Marco Antognini & Jamila Sam
 */

#pragma once

#include <SFML/System.hpp>

/*!
 * @class Updatable
 *
 * @brief Represents an entity that evolves with time
 */
class Updatable
{
public:
    virtual ~Updatable() = default;

    virtual void update(sf::Time dt) = 0;
};

