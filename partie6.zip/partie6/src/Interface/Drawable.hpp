/*
 * POOSV 2016-2024
 * Marco Antognini & Jamila Sam
 */

#pragma once

#include <SFML/Graphics.hpp>
#include<Env/DrawingPriority.h>

/*!
 * @class Drawable
 *
 * @brief Represents an entity that can be represented graphically
 */
class Drawable
{
public:
    virtual ~Drawable() = default;

    virtual void drawOn(sf::RenderTarget& target) const = 0;

    virtual DrawingPriority getDepth() const
    {
        return DrawingPriority::DEFAULT_PRIORITY;
    }
};

