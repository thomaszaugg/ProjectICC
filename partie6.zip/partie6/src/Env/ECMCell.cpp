#include "ECMCell.hpp"

ECMCell::ECMCell(CellsLayer* cellsLayer)
    :Cell(cellsLayer){}

void ECMCell::update(sf::Time ){

}
